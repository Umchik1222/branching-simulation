public class I {

    private double k = 100.500;

    private double i = 100.500;

    public java.lang.Class qq() {
        return getClass();
    }

    public float ff() {
        return 0;
    }

    public int ae() {
        return 8;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
