public class K extends null {

    String kk();

    byte oo();
}
