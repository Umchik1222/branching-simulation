public class I extends null {

    private double k = 100.500;

    private double i = 100.500;

    public java.lang.Class qq() {
        return getClass();
    }

    public float ff() {
        return 0;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public String kk() {
        return "No";
    }

    public int ae() {
        return 8;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public double ee() {
        return 100.500;
    }

    public Object pp() {
        return this;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public byte oo() {
        return 4;
    }
}
