public class D extends null implements K {

    private byte e = 1;

    private String d = "hello";

    public double ee() {
        return 100.500;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public String kk() {
        return "No";
    }

    public byte oo() {
        return 1;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public long dd() {
        return 99999;
    }

    public void ab() {
        System.out.println();
    }

    public void aa() {
        return;
    }

    public int af() {
        return -1;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public int cc() {
        return 39;
    }

    public float ff() {
        return 0;
    }
}
