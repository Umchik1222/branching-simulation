public class H implements K {

    private double k = 100.500;

    private double f = 100.500;

    public int af() {
        return -1;
    }

    public long ac() {
        return 111;
    }

    public String kk() {
        return "No";
    }

    public byte oo() {
        return 1;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }
}
