public interface K {

    String kk();

    byte oo();
}
